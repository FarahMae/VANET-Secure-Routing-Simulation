# VANET Secure Routing Simulation Using Python

[![Status](https://img.shields.io/badge/status-complete-brightgreen)]()
[![Platform](https://img.shields.io/badge/platform-Google%20Colab-yellow)]()
[![Language](https://img.shields.io/badge/python-3.10+-blue)]()

## 📌 Overview

This project simulates secure routing in Vehicular Ad Hoc Networks (VANET) using Python. 
It uses SHA-256 hashing for message integrity and detects impersonation and replay attacks.

## ✅ Features
- SHA-256 message hashing
- Replay attack prevention
- Impersonation detection
- Hash time performance graph

## 📊 Simulation Output

### SHA-256 Hash Time per Message
![Hash Time](screenshots/sha256_hash_time_graph.png)

### Replay Attack Detection
![Replay Attack](screenshots/replay_attack_output.png)

## 🚀 How to Run

Open the notebook in Google Colab:  
[Open in Google Colab](https://colab.research.google.com/drive/1daZvpwJN-RVujtpYGePa7RqfpQbh1rdF)

## 👩‍💻 Author

**Farah Mae Sumajit**
